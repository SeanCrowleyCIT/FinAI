# Susan O'Mahony 
# 02/12/20
# susan.omahony@mycit.ie

import numpy as np
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import load_model
from pickle import load

class PredictLoan:

    def __init__(self, liste):
        self.lst = [liste]
        self.X = np.array(self.lst, dtype=np.float32)

    def get_eligibility(self):
        
        #load the model created when the model was trained
        model = load_model('models/loan/active_model/model.h5')
        # open the scaler file created when the model was trained
        scaler = load(open('models/loan/active_model/scaler.pkl', 'rb'))
        self.X = scaler.transform(self.X)
        pred = model.predict(self.X)
        
        #The accuracy is around 82% and I've set the threshold for 
        #eligibility at 10%. This might seem low but eligibility 
        #seems to depend overwhelmingly on credit history and if 
        #someone has a poor credit history, a zero, the probability 
        #of them getting a loan is very low (~4%) even with high incomes.
        
        if pred > 10:
            return 'Eligible'
        else:
            return 'Ineligible'