from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, IntegerField, FloatField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo
from wtforms.fields.html5 import DateField


#TO Do: sign in form

#TO Do: Register form


class HousingForm(FlaskForm):
    num_bedrooms = IntegerField('Number of bedrooms', validators=[DataRequired(), Length(min=1)])
    num_bathrooms = IntegerField('Number of bathrooms', validators=[DataRequired(), Length(min=1)])
    num_floors = IntegerField('Number of floors', validators=[DataRequired(), Length(min=1)])
    sqft_living_past = IntegerField('Sqft. living past', validators=[DataRequired(), Length(min=1)])
    sqft_lot_past = IntegerField('Sqft. lot past', validators=[DataRequired(), Length(min=1)])
    sqft_living_present = IntegerField('Sqft. living present', validators=[DataRequired(), Length(min=1)])
    sqft_lot_present = IntegerField('Sqft. lot present', validators=[DataRequired(), Length(min=1)])
    sqft_above = IntegerField('Sqft. Above', validators=[DataRequired(), Length(min=1)])
    sqft_basement = IntegerField('Sqft. basement', validators=[DataRequired(), Length(min=1)])
    zip_code = StringField('Zipcode', validators=[DataRequired(), Length(min=1)])
    latitude = FloatField('Latitude', validators=[DataRequired(), Length(min=1)])
    longitude = FloatField('Longitude', validators=[DataRequired(), Length(min=1)])
    waterfront = SelectField('Waterfront', validators=[DataRequired(), Length(min=1)], choices=[('', 'Does dwelling have waterfrontage:'), ('1', 'Yes'), ('0', 'No')])
    view = SelectField('View', validators=[DataRequired(), Length(min=1)], choices=[('', 'Select view rating:'),('0', '0'), ('1', '1'), ('2', '2'), ('3', '3'), ('4', '4')])
    condition = SelectField('Condition', validators=[DataRequired(), Length(min=1)], choices=[('', 'Select condition rating:'),('1', '1'), ('2', '2'), ('3', '3'), ('4', '4'), ('5', '5')])
    grade = SelectField('Grade', validators=[DataRequired(), Length(min=1)], choices=[('', 'Select grade rating:'),('1', '1'), ('3', '3'), ('4', '4'), ('5', '5'), ('6', '6'), ('7', '7'), ('8', '8'), ('9', '9'), ('10', '10'), ('11', '11'), ('12', '12'), ('13', '13')])                         
    year_built = DateField('Year built', validators=[DataRequired()], format='%d-%m-%Y')
    year_renovated = DateField('Year renovated', validators=[DataRequired()], format='%d-%m-%Y')
    submit = SubmitField('Calculate')    
