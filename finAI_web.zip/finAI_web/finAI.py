from flask import Flask, render_template
from forms import HousingForm
app = Flask(__name__)

#Key Used for testing
app.config['SECRET_KEY'] = '21cc0dbf01b48ac7330f8be653d32a50'

@app.route('/')
@app.route('/clients')
@app.route('/approvals')
@app.route('/home')
def home():
    return render_template('home.html')
    
@app.route("/reporting")
def reporting():
    return render_template('reporting.html')

@app.route("/lending")
def lending():
    return render_template('lending.html')
    
@app.route("/housing")
def housing():
    form = HousingForm()
    if form.validate_on_submit():
        print(form.data) # Form data as a dict
        return redirect(url_for('home'))
    return render_template('housing.html', form=form)
 
@app.route("/account")
def account():
    return render_template('account.html')
    
@app.route("/payment")
def payment():
    return render_template('payment.html')

if __name__ == '__main__':
    app.run(debug=True)