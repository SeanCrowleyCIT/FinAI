# Jordan Hennessy 
# 30/11/20
# jordan.hennessy@mycit.ie

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, IntegerField, FloatField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo, InputRequired
from wtforms.fields.html5 import DateField


#TO Do: sign in form

#TO Do: Register form


class HousingForm(FlaskForm):
    num_bedrooms = IntegerField('No. of bedrooms', validators=[InputRequired()])
    num_bathrooms = FloatField('No. of bathrooms', validators=[InputRequired()])
    num_floors = FloatField('No. of floors', validators=[DataRequired()])
    sqft_living_past = IntegerField('Sqft. living past', validators=[DataRequired()])
    sqft_lot_past = IntegerField('Sqft. lot past', validators=[DataRequired()])
    sqft_living_present = IntegerField('Sqft. living present', validators=[DataRequired()])
    sqft_lot_present = IntegerField('Sqft. lot present', validators=[DataRequired()])
    sqft_above = IntegerField('Sqft. Above', validators=[DataRequired()])
    sqft_basement = IntegerField('Sqft. basement', validators=[InputRequired()])
    zip_code = IntegerField('Zipcode', validators=[DataRequired()])
    latitude = FloatField('Latitude', validators=[DataRequired()])
    longitude = FloatField('Longitude', validators=[DataRequired()])
    waterfront = SelectField('Waterfront', validators=[DataRequired(), 
        Length(min=1)], choices=[('', ''), 
        ('1', 'Yes'), ('0', 'No')])
    view = SelectField('View', validators=[DataRequired()], 
        choices=[('', ''),('0', '0'), ('1', '1'), ('2', '2'), 
        ('3', '3'), ('4', '4')])
    condition = SelectField('Condition', validators=[DataRequired()], 
        choices=[('', ''),('1', '1'), ('2', '2'), ('3', '3'), 
        ('4', '4'), ('5', '5')])
    grade = SelectField('Grade', validators=[DataRequired()], 
        choices=[('', ''),('1', '1'), ('3', '3'), ('4', '4'), 
        ('5', '5'), ('6', '6'), ('7', '7'), ('8', '8'), ('9', '9'), ('10', '10'), 
        ('11', '11'), ('12', '12'), ('13', '13')])
    year_built = IntegerField('Year built', validators=[DataRequired()])
    year_renovated = IntegerField('Year renovated', validators=[InputRequired()])
    submit = SubmitField('Calculate')
