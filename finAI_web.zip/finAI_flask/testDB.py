#from flask import Flask, jsonify, request, redirect, url_for, render_template
#from flask_restful import Resource, Api, reqparse
#app = Flask(__name__)
#api = Api(app)
#import os
#pyrelist = []
#SECRET_KEY = os.urandom(32)
#app.config['SECRET_KEY'] = SECRET_KEY

import pyrebase
config = {
  "apiKey": "AIzaSyBnMEwJ4cfyivrofIUb3EEC2qmmCU7oTHo",
  "authDomain": "fin-ai-50427.firebaseapp.com",
  "databaseURL": "https://fin-ai-50427.firebaseio.com",
  "storageBucket": "fin-ai-50427.appspot.com",
  "serviceAccount": "fin-ai-50427-firebase-adminsdk-vj6dm-c630798cad.json"
}

#https://github.com/thisbejim/Pyrebase

# get all data from table
firebase = pyrebase.initialize_app(config)
db = firebase.database()


# Select where equal to 
#users = db.child("users").order_by_child("Email").equal_to('joker14.cc@gmail.com').get()
#print(users.val())

#print("\n")

users = db.child("house_pricing").get()
print(users.val())

print("\n")

#users_by_name = db.child("users").order_by_child("Email").get()

#for user in users:
#    if users["Email"] == "joker14.cc@gmail.com":
#        print(users["Email"])

