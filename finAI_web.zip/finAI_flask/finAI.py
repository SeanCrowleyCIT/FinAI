# Jordan Hennessy 
# 30/11/20
# jordan.hennessy@mycit.ie

from flask import Flask, render_template, url_for, flash, redirect
from forms import HousingForm
from predict_price import PredictPrice

app = Flask(__name__)

#Key Used for testing
app.config['SECRET_KEY'] = '21cc0dbf01b48ac7330f8be653d32a50'

@app.route('/')
@app.route('/clients')
@app.route('/approvals')
@app.route('/home')
def home():
    return render_template('home.html')
    
@app.route("/reporting")
def reporting():
    return render_template('reporting.html')

@app.route("/lending")
def lending():
    return render_template('lending.html')
    
@app.route("/housing", methods=['GET', 'POST'])
def housing():
    form = HousingForm()
    pricing_model_data = []
    if form.validate_on_submit():
        #Add dictionary values to list in the order machine learning
            # script will expect
        pricing_model_data.append(form.data["num_bedrooms"])
        pricing_model_data.append(form.data["num_bathrooms"])
        pricing_model_data.append(form.data["sqft_living_past"])
        pricing_model_data.append(form.data["sqft_lot_past"])
        pricing_model_data.append(form.data["num_floors"])
        pricing_model_data.append(form.data["waterfront"])
        pricing_model_data.append(form.data["view"])
        pricing_model_data.append(form.data["condition"])
        pricing_model_data.append(form.data["grade"])
        pricing_model_data.append(form.data["sqft_above"])
        pricing_model_data.append(form.data["sqft_basement"])
        pricing_model_data.append(form.data["year_built"])
        pricing_model_data.append(form.data["year_renovated"])
        pricing_model_data.append(form.data["zip_code"])
        pricing_model_data.append(form.data["latitude"])
        pricing_model_data.append(form.data["longitude"])
        pricing_model_data.append(form.data["sqft_living_present"])
        pricing_model_data.append(form.data["sqft_lot_present"])
        price_prediction = PredictPrice(pricing_model_data)
        price = "{:20,.2f}".format(price_prediction.get_price())
        #print(price)
        #return redirect(url_for('housing', price="test"))
        return render_template('housing.html', form=form, price=price)
    return render_template('housing.html', form=form)
 
@app.route("/account")
def account():
    return render_template('account.html')
    
@app.route("/payment")
def payment():
    return render_template('payment.html')

if __name__ == '__main__':
    app.run(debug=True)