from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
@app.route('/clients')
@app.route('/approvals')
@app.route('/home')
def home():
    return render_template('home.html')
    
@app.route("/reporting")
def reporting():
    return render_template('reporting.html')

@app.route("/lending")
def lending():
    return render_template('lending.html')
    
@app.route("/housing")
def housing():
    return render_template('housing.html')
 
@app.route("/account")
def account():
    return render_template('account.html')
    
@app.route("/payment")
def payment():
    return render_template('payment.html')

if __name__ == '__main__':
    app.run(debug=True)