# Jordan Hennessy 
# 30/11/20
# jordan.hennessy@mycit.ie

import pandas as pd
import joblib
import numpy as np

class PredictPrice:
    
    def __init__(self, liste):
        self.lst = [liste]
        self.dFrame = pd.DataFrame(self.lst, columns =['bedrooms', 'bathrooms', 'sqft_living', 'sqft_lot', 'floors', 
            'waterfront', 'view', 'condition', 'grade', 'sqft_above', 'sqft_basement', 'yr_built', 'yr_renovated', 
            'zipcode', 'lat', 'long', 'sqft_living15', 'sqft_lot15']) 

    def get_price(self):
        #Pull previously saved model
        loaded_model = joblib.load("models/price/active_model/finalized_model.sav")
        # Make prediction with model
        result = loaded_model.predict(self.dFrame)[0]
        #print("Predicted price: $ {:.2f}".format(result)) 
        return result