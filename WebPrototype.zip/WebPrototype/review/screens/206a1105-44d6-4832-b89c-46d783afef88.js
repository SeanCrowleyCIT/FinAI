var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-206a1105-44d6-4832-b89c-46d783afef88" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Lending" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/206a1105-44d6-4832-b89c-46d783afef88-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/206a1105-44d6-4832-b89c-46d783afef88-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/206a1105-44d6-4832-b89c-46d783afef88-1602092238182-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="15.0px" datasizeheight="11.5px" dataX="1205.0" dataY="19.0"   alt="image" systemName="./images/328ccbce-cc77-4252-af65-3deb1fec1bea.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Arrow Left</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_1-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#CBCBCB" id="s-Image_1-Components" transform="translate(-658.000000, -518.000000)">\
          	            <g id="s-Image_1-Inputs" transform="translate(100.000000, 498.000000)">\
          	                <g id="s-Image_1-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
          	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#FFFFFF !important;" />\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="175.0px" datasizeheight="128.0px" dataX="-1.5" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3ed46cae-54a5-4a89-b668-4607ef4a2c31.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Line_1" customid="Line 5" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="1100.0px" datasizeheight="2.0px" datasizewidthpx="1100.0" datasizeheightpx="2.0" dataX="61.5" dataY="111.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 5" d="M 0.0 1.0 L 1100.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="186.0" datasizeheightpx="95.99999999999994" dataX="257.0" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Clients</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="439.0" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">Reporting</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="611.5" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Lending</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="797.5" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0">Housing</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="228.5px" datasizeheight="42.0px" datasizewidthpx="228.45505941742408" datasizeheightpx="42.00000000000014" dataX="1051.5" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">Jordan</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Triangle_1" customid="Triangle 1" class="shapewrapper shapewrapper-s-Triangle_1 non-processed"  rotationdeg="180" datasizewidth="19.0px" datasizeheight="15.0px" datasizewidthpx="19.0" datasizeheightpx="15.0" dataX="1201.5" dataY="16.0" originalwidth="19.0px" originalheight="15.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Triangle_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Triangle_1)">\
                          <path id="s-Triangle_1" class="pie triangle shape non-processed-shape manualfit firer commentable non-processed" customid="Triangle 1" d="M 9.0 0.0 L 19.0 15.0 L 0.0 15.0 Z">\
                          </path>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Triangle_1" class="clipPath">\
                          <path d="M 9.0 0.0 L 19.0 15.0 L 0.0 15.0 Z">\
                          </path>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Triangle_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Triangle_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 1"   datasizewidth="608.0px" datasizeheight="85.0px" datasizewidthpx="608.0" datasizeheightpx="85.0" dataX="321.0" dataY="128.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0">Loan Eligibility Calculator</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="898.0px" datasizeheight="1944.0px" datasizewidthpx="898.0000000000005" datasizeheightpx="1944.0000000000007" dataX="191.0" dataY="292.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_8" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="342.3" dataY="301.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0">Personal Loan Eligibility Calculator</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_9" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 8"   datasizewidth="768.0px" datasizeheight="80.0px" datasizewidthpx="768.0" datasizeheightpx="80.0" dataX="241.0" dataY="187.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_9_0">This loan eligibility calculator can determine if a candidate is eligible for a loan with a banking institution.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_10" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="191.0" dataY="400.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_10_0">First Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="398.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_11" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="191.0" dataY="475.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_11_0">Last Name</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="473.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_12" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="183.0" dataY="549.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_12_0">Address</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="547.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="599.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_5" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="654.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_13" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="191.0" dataY="727.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_13_0">Date of birth</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_6" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="725.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="shapewrapper-s-Line_2" customid="Line 2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="228.0" dataY="823.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_14" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="227.5" dataY="777.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_14_0">Marital Status</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_15" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="398.0" dataY="876.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_15_0">Married</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_16" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="656.5" dataY="876.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_16_0">Not Married</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
        <div id="s-Radio_button_1" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 1" datasizewidth="13.0px" datasizeheight="13.0px" dataX="430.0" dataY="888.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
\
        <div id="s-Radio_button_2" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 2" datasizewidth="13.0px" datasizeheight="13.0px" dataX="674.0" dataY="888.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
      <div id="shapewrapper-s-Line_3" customid="Line 4" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="224.2" dataY="972.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 4" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_17" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="223.8" dataY="926.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_17_0">Gender</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_18" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="394.2" dataY="1025.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_18_0">Male</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_19" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="652.7" dataY="1025.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_19_0">Female</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
        <div id="s-Radio_button_3" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 5" datasizewidth="13.0px" datasizeheight="13.0px" dataX="426.2" dataY="1037.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
\
        <div id="s-Radio_button_4" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 6" datasizewidth="13.0px" datasizeheight="13.0px" dataX="670.2" dataY="1037.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
      <div id="shapewrapper-s-Line_4" customid="Line 4" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="224.2" dataY="1129.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 4" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_20" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="223.8" dataY="1083.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_20_0">Education</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_21" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="394.2" dataY="1182.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_21_0">Graduate</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_22" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="652.7" dataY="1182.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_22_0">Not Graduated</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
        <div id="s-Radio_button_5" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 5" datasizewidth="13.0px" datasizeheight="13.0px" dataX="426.2" dataY="1194.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
\
        <div id="s-Radio_button_6" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 6" datasizewidth="13.0px" datasizeheight="13.0px" dataX="670.2" dataY="1194.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
      <div id="shapewrapper-s-Line_5" customid="Line 4" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="224.2" dataY="1265.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_5" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 4" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_23" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="223.8" dataY="1219.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_23_0">Dependents</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_24" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="1309.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_24_0">Number of dependents</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_7" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1307.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="shapewrapper-s-Line_6" customid="Line 6" class="shapewrapper shapewrapper-s-Line_6 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="224.2" dataY="1403.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_6" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_6" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 6" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_25" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="223.8" dataY="1357.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_25_0">Employment</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_26" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="394.2" dataY="1456.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_26_0">Yes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_27" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="652.7" dataY="1456.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_27_0">No</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
        <div id="s-Radio_button_7" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 7" datasizewidth="13.0px" datasizeheight="13.0px" dataX="426.2" dataY="1468.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
\
        <div id="s-Radio_button_8" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 8" datasizewidth="13.0px" datasizeheight="13.0px" dataX="670.2" dataY="1468.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
      <div id="s-Rectangle_28" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="183.0" dataY="1456.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_28_0">Self employed</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_29" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="196.0" dataY="1515.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_29_0">Applicant income</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_8" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1513.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="$"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_30" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="209.0" dataY="1586.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_30_0">Coapplicant income</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_9" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1584.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="$"/></div></div>  </div></div></div>\
      <div id="shapewrapper-s-Line_7" customid="Line 7" class="shapewrapper shapewrapper-s-Line_7 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="224.2" dataY="1704.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_7" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_7" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 7" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_31" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="223.8" dataY="1658.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_31_0">Loan</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_32" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="183.0" dataY="1747.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_32_0">Loan Amount</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_10" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1745.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="$"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_33" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="183.0" dataY="1821.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_33_0">Term in Days</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_11" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1819.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="shapewrapper-s-Line_8" customid="Line 8" class="shapewrapper shapewrapper-s-Line_8 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="224.1" dataY="1946.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_8" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_8" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 8" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_34" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="223.6" dataY="1900.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_34_0">Property</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_35" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="398.0" dataY="2000.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_35_0">Urban</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_36" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="611.5" dataY="2000.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_36_0">Semi Urban</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
        <div id="s-Radio_button_9" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 9" datasizewidth="13.0px" datasizeheight="13.0px" dataX="430.0" dataY="2012.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
\
        <div id="s-Radio_button_10" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 10" datasizewidth="13.0px" datasizeheight="13.0px" dataX="632.0" dataY="2012.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
      <div id="s-Rectangle_37" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="186.8" dataY="2001.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_37_0">Property Area</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
        <div id="s-Radio_button_11" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 11" datasizewidth="13.0px" datasizeheight="13.0px" dataX="839.0" dataY="2012.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
      <div id="s-Rectangle_38" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="817.5" dataY="2000.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_38_0">Rural</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_39" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 40"   datasizewidth="280.3px" datasizeheight="64.0px" datasizewidthpx="280.27549689500546" datasizeheightpx="64.0" dataX="499.9" dataY="2091.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_39_0">Calculate</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_40" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 41"   datasizewidth="175.3px" datasizeheight="36.0px" datasizewidthpx="175.30739636481152" datasizeheightpx="36.0" dataX="552.3" dataY="2171.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_40_0">Reset</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;