var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-408399bf-18dc-4fd2-b63a-5f0266779bf6" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Reporting" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/408399bf-18dc-4fd2-b63a-5f0266779bf6-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/408399bf-18dc-4fd2-b63a-5f0266779bf6-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/408399bf-18dc-4fd2-b63a-5f0266779bf6-1602092238182-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="175.0px" datasizeheight="128.0px" dataX="-8.0" dataY="-15.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3ed46cae-54a5-4a89-b668-4607ef4a2c31.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Line_1" customid="Line 3" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="1100.0px" datasizeheight="2.0px" datasizewidthpx="1100.0" datasizeheightpx="2.0" dataX="55.0" dataY="96.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 3" d="M 0.0 1.0 L 1100.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="186.0" datasizeheightpx="95.99999999999994" dataX="250.5" dataY="1.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Clients</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="432.5" dataY="1.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">Reporting</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="605.0" dataY="1.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Lending</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="791.0" dataY="1.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0">Housing</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="225.0px" datasizeheight="42.0px" datasizewidthpx="225.0" datasizeheightpx="42.00000000000017" dataX="1055.0" dataY="-2.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">Jordan</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="225.0px" datasizeheight="42.0px" datasizewidthpx="225.0" datasizeheightpx="42.00000000000017" dataX="1051.5" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0">Jordan</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Triangle_1" customid="Triangle 1" class="shapewrapper shapewrapper-s-Triangle_1 non-processed"  rotationdeg="180" datasizewidth="19.0px" datasizeheight="15.0px" datasizewidthpx="19.0" datasizeheightpx="15.0" dataX="1055.0" dataY="328.0" originalwidth="19.0px" originalheight="15.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Triangle_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Triangle_1)">\
                          <path id="s-Triangle_1" class="pie triangle shape non-processed-shape manualfit firer commentable non-processed" customid="Triangle 1" d="M 9.0 0.0 L 19.0 15.0 L 0.0 15.0 Z">\
                          </path>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Triangle_1" class="clipPath">\
                          <path d="M 9.0 0.0 L 19.0 15.0 L 0.0 15.0 Z">\
                          </path>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Triangle_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Triangle_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="15.0px" datasizeheight="11.5px" dataX="1205.0" dataY="19.0"   alt="image" systemName="./images/f516a177-6daf-40a2-a556-1b1b991f2b97.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Arrow Left</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_2-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#CBCBCB" id="s-Image_2-Components" transform="translate(-658.000000, -518.000000)">\
          	            <g id="s-Image_2-Inputs" transform="translate(100.000000, 498.000000)">\
          	                <g id="s-Image_2-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
          	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#FFFFFF !important;" />\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 1"   datasizewidth="311.5px" datasizeheight="393.0px" datasizewidthpx="311.50000000000006" datasizeheightpx="393.0000000000003" dataX="32.0" dataY="141.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="710.5px" datasizeheight="429.5px" dataX="419.0" dataY="155.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/78f34e2f-818a-4a35-88b6-0e15be04e91e.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_8" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="286.0px" datasizeheight="58.0px" datasizewidthpx="285.9951338199513" datasizeheightpx="58.0" dataX="45.8" dataY="169.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0">Count - Loan Status</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_9" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="286.0px" datasizeheight="58.0px" datasizewidthpx="285.9951338199513" datasizeheightpx="58.0" dataX="44.8" dataY="238.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_9_0">Loan Status - Loan Amount</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_10" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="286.0px" datasizeheight="58.0px" datasizewidthpx="285.9951338199513" datasizeheightpx="58.0" dataX="44.8" dataY="306.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_10_0">Count - Approved by Area</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_11" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="286.0px" datasizeheight="58.0px" datasizewidthpx="285.9951338199513" datasizeheightpx="58.0" dataX="44.8" dataY="379.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_11_0">Count - Unapproved by Area</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_2" customid="Line 2" class="shapewrapper shapewrapper-s-Line_2 non-processed"  rotationdeg="90" datasizewidth="646.0px" datasizeheight="2.0px" datasizewidthpx="646.0" datasizeheightpx="2.0" dataX="78.0" dataY="444.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 1.0 L 646.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_3" customid="Line 3" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="871.4px" datasizeheight="2.0px" datasizewidthpx="871.4416878569554" datasizeheightpx="2.0" dataX="403.0" dataY="586.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 3" d="M 0.0 1.0 L 871.4416878569554 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Table_1" class="pie table firer commentable non-processed" customid="Table 1"  datasizewidth="622.0px" datasizeheight="139.0px" dataX="492.0" dataY="629.0" originalwidth="621.0000000000005px" originalheight="137.9999999999999px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Text_cell_7" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 1"     datasizewidth="311.5px" datasizeheight="47.0px" dataX="0.0" dataY="0.0" originalwidth="310.5000000000005px" originalheight="45.99999999999995px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_7_0">Loan Status</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_8" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 4"     datasizewidth="311.5px" datasizeheight="47.0px" dataX="0.0" dataY="0.0" originalwidth="310.5000000000005px" originalheight="45.99999999999995px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_8_0">Count</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_9" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 2"     datasizewidth="311.5px" datasizeheight="47.0px" dataX="0.0" dataY="0.0" originalwidth="310.5000000000005px" originalheight="45.99999999999995px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_9_0">Approved</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_10" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 5"     datasizewidth="311.5px" datasizeheight="47.0px" dataX="0.0" dataY="0.0" originalwidth="310.5000000000005px" originalheight="45.99999999999995px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_10_0">700</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_11" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 3"     datasizewidth="311.5px" datasizeheight="47.0px" dataX="0.0" dataY="0.0" originalwidth="310.5000000000005px" originalheight="45.99999999999995px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_11_0">Unappoved</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_12" class="pie textcell manualfit firer ie-background non-processed" customid="Text cell 6"     datasizewidth="311.5px" datasizeheight="47.0px" dataX="0.0" dataY="0.0" originalwidth="310.5000000000005px" originalheight="45.99999999999995px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_12_0">280</span></div></div></div></div></div></div>  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;