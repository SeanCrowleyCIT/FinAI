var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-5a6f1dc9-ecf7-4704-b330-c586490e7d61" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Housing" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/5a6f1dc9-ecf7-4704-b330-c586490e7d61-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/5a6f1dc9-ecf7-4704-b330-c586490e7d61-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/5a6f1dc9-ecf7-4704-b330-c586490e7d61-1602092238182-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="15.0px" datasizeheight="11.5px" dataX="1205.0" dataY="19.0"   alt="image" systemName="./images/5da23356-3526-473c-b514-6bf687cce514.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Arrow Left</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_1-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#CBCBCB" id="s-Image_1-Components" transform="translate(-658.000000, -518.000000)">\
          	            <g id="s-Image_1-Inputs" transform="translate(100.000000, 498.000000)">\
          	                <g id="s-Image_1-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
          	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#FFFFFF !important;" />\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="175.0px" datasizeheight="128.0px" dataX="-1.5" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3ed46cae-54a5-4a89-b668-4607ef4a2c31.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Line_1" customid="Line 1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="1100.0px" datasizeheight="2.0px" datasizewidthpx="1100.0" datasizeheightpx="2.0" dataX="61.5" dataY="111.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 1" d="M 0.0 1.0 L 1100.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="186.0" datasizeheightpx="95.99999999999994" dataX="257.0" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Clients</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="439.0" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">Reporting</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="611.5" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Lending</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="797.5" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0">Housing</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="228.5px" datasizeheight="42.0px" datasizewidthpx="228.45505941742408" datasizeheightpx="42.00000000000014" dataX="1051.5" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">Jordan</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Triangle_1" customid="Triangle 1" class="shapewrapper shapewrapper-s-Triangle_1 non-processed"  rotationdeg="180" datasizewidth="19.0px" datasizeheight="15.0px" datasizewidthpx="19.0" datasizeheightpx="15.0" dataX="1201.5" dataY="16.0" originalwidth="19.0px" originalheight="15.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Triangle_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Triangle_1)">\
                          <path id="s-Triangle_1" class="pie triangle shape non-processed-shape manualfit firer commentable non-processed" customid="Triangle 1" d="M 9.0 0.0 L 19.0 15.0 L 0.0 15.0 Z">\
                          </path>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Triangle_1" class="clipPath">\
                          <path d="M 9.0 0.0 L 19.0 15.0 L 0.0 15.0 Z">\
                          </path>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Triangle_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Triangle_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 1"   datasizewidth="608.0px" datasizeheight="85.0px" datasizewidthpx="608.0" datasizeheightpx="85.0" dataX="321.0" dataY="128.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0">House Quotation Calculator</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="898.0px" datasizeheight="1908.0px" datasizewidthpx="898.0000000000007" datasizeheightpx="1908.0000000000014" dataX="176.0" dataY="292.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_8" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 2"   datasizewidth="579.5px" datasizeheight="68.0px" datasizewidthpx="579.4550594174239" datasizeheightpx="68.0" dataX="342.3" dataY="301.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0">House Price Quotation Calculator</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_9" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 8"   datasizewidth="768.0px" datasizeheight="80.0px" datasizewidthpx="768.0" datasizeheightpx="80.0" dataX="241.0" dataY="187.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_9_0">This House Quotation Calculator gives a recommended purchase price for a domestic building. </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_10" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="400.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_10_0">Asking Price</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="398.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="$"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_11" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="475.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_11_0">Number of bedrooms</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="473.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="547.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_12" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="470.5" dataY="933.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_12_0">Yes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_13" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="656.5" dataY="933.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_13_0">No</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
        <div id="s-Radio_button_1" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 5" datasizewidth="13.0px" datasizeheight="13.0px" dataX="525.5" dataY="945.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
\
        <div id="s-Radio_button_2" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 6" datasizewidth="13.0px" datasizeheight="13.0px" dataX="691.5" dataY="945.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
      <div id="s-Rectangle_14" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 40"   datasizewidth="280.3px" datasizeheight="64.0px" datasizewidthpx="280.27549689500546" datasizeheightpx="64.0" dataX="517.2" dataY="1775.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_14_0">Calculate</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_15" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 41"   datasizewidth="175.3px" datasizeheight="36.0px" datasizewidthpx="175.30739636481152" datasizeheightpx="36.0" dataX="568.8" dataY="1866.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_15_0">Reset</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_16" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="549.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_16_0">Number of bathrooms</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_17" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="626.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_17_0">Number of bathrooms</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_4" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="624.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_18" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="705.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_18_0">Sqr. ft. Living Space</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_5" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="703.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_6" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="779.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_19" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="781.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_19_0">Sqr. ft. Land Space</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_7" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="855.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_20" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="857.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_20_0">Number of Floors</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_21" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="933.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_21_0">Waterfront Property</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_1" class="pie dropdown firer commentable non-processed" customid="Category 1"    datasizewidth="311.0px" datasizeheight="39.0px" dataX="496.0" dataY="1000.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Select</div></div></div></div></div><select id="s-Category_1-options" class="s-5a6f1dc9-ecf7-4704-b330-c586490e7d61 dropdown-options" ><option selected="selected" class="option">Select</option>\
      <option  class="option">1</option>\
      <option  class="option">2</option>\
      <option  class="option">3</option>\
      <option  class="option">4</option>\
      <option  class="option">0</option></select></div>\
      <div id="s-Rectangle_22" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="1001.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_22_0">View</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_2" class="pie dropdown firer commentable non-processed" customid="Category 1"    datasizewidth="311.0px" datasizeheight="39.0px" dataX="496.0" dataY="1074.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Select</div></div></div></div></div><select id="s-Category_2-options" class="s-5a6f1dc9-ecf7-4704-b330-c586490e7d61 dropdown-options" ><option selected="selected" class="option">Select</option>\
      <option  class="option"><br /></option>\
      <option  class="option">1</option>\
      <option  class="option">2</option>\
      <option  class="option">3</option>\
      <option  class="option">4</option>\
      <option  class="option">5</option></select></div>\
      <div id="s-Rectangle_23" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="1075.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_23_0">Condition</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_3" class="pie dropdown firer commentable non-processed" customid="Category 1"    datasizewidth="311.0px" datasizeheight="39.0px" dataX="496.0" dataY="1149.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Select</div></div></div></div></div><select id="s-Category_3-options" class="s-5a6f1dc9-ecf7-4704-b330-c586490e7d61 dropdown-options" ><option selected="selected" class="option">Select</option>\
      <option  class="option"><br /></option>\
      <option  class="option">1</option>\
      <option  class="option">2</option>\
      <option  class="option">3</option>\
      <option  class="option">4</option>\
      <option  class="option">5</option>\
      <option  class="option">6</option>\
      <option  class="option">7</option>\
      <option  class="option">8</option>\
      <option  class="option">9</option>\
      <option  class="option">10</option>\
      <option  class="option">11</option>\
      <option  class="option">12</option>\
      <option  class="option">13</option></select></div>\
      <div id="s-Rectangle_24" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="1150.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_24_0">Grade</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_8" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1223.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_25" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="1225.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_25_0">Sqr. ft. Above</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_9" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1294.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_26" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="1296.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_26_0">Sqr. ft. Basement</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_10" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1366.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_27" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="1368.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_27_0">Year Built</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_11" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1439.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_28" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="225.3" dataY="1441.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_28_0">Year Renovated</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_29" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="233.0" dataY="1516.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_29_0">Zipcode</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_12" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1514.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_13" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1586.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_30" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="233.0" dataY="1588.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_30_0">Latitude</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_14" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="496.0" dataY="1660.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_31" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="233.0" dataY="1662.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_31_0">Longitude</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_2" customid="Line 9" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="217.0" dataY="1936.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 9" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_32" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 14"   datasizewidth="447.5px" datasizeheight="122.0px" datasizewidthpx="447.45505941742346" datasizeheightpx="122.0" dataX="427.8" dataY="1935.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_32_0">Recommended Purchase Price:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_15" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="78.0px" dataX="501.0" dataY="2036.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="$"/></div></div>  </div></div></div>\
      <div id="shapewrapper-s-Line_3" customid="Line 2" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="816.0px" datasizeheight="2.0px" datasizewidthpx="816.0" datasizeheightpx="2.0" dataX="217.0" dataY="1940.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 1.0 L 816.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;