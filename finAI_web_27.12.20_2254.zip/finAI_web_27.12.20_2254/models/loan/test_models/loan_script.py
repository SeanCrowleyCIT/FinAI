# Susan O'Mahony 
# 02/12/20
# susan.omahony@mycit.ie


# The preprocessing of the data in the 11 columns when the model was trained:
# df['Gender'].replace('Male',0,inplace=True)
# df['Gender'].replace('Female',1,inplace=True)
# df['Married'].replace('No',0,inplace=True)
# df['Married'].replace('Yes',1,inplace=True)
# df['Dependents'].replace('0',0,inplace=True)
# df['Dependents'].replace('1',1,inplace=True)
# df['Dependents'].replace('2',2,inplace=True)
# df['Dependents'].replace('3+',3,inplace=True)
# df['Education'].replace('Graduate',0,inplace=True)
# df['Education'].replace('Not Graduate',1,inplace=True)
# df['Self_Employed'].replace('No',0,inplace=True)
# df['Self_Employed'].replace('Yes',1,inplace=True)
# ApplicantIncome
# CoapplicantIncome
# LoanAmount
# Loan_Amount_Term
# Credit_History
# df['Property_Area'].replace('Urban',0,inplace=True)
# df['Property_Area'].replace('Rural',1,inplace=True)
# df['Property_Area'].replace('Semiurban',2,inplace=True)

import numpy as np
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import load_model
from pickle import load

# load the model created when the model was trained
model = load_model('model.h5')

X = np.array([[0, 1, 0, 0, 1, 500, 300, 6, 360, 0, 0]], dtype=np.float32)

# open the scaler file created when the model was trained
scaler = load(open('scaler.pkl', 'rb'))
X = scaler.transform(X)

pred = model.predict(X)

print(X)

print("Probability that eligibility = Yes:")
print(pred)


if pred > 10:
    print('Eligible')
else:
    print('Ineligible')
	
	
