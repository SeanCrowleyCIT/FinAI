from data import Users, Clients, Loan_Table, Price_Table, Broker, Approval

cl = Clients
a = Approval
pt = Price_Table
client_email = "maryh@hotmail.com"
email2 = "p.cleary@icloud.com"
#key = cl.getClientKey(email2)
#cl.setApprovalPending(client_email)
#print("Key is --", key, "--")


cl.dropClientTable()
#(customer_name, customer_email, customer_contact, owner)

#cl.addClient("Tom Petty", "tompy2@gmail.com", "08793037473", "jordan.hennessy@mycit.ie")

#cl.TestsetApprovalPending("tompy@gmail.com")
#cl.removeClient("tompy2@gmail.com")

#a.dropLoanTable()
#a.dropApprovalTable()
#print(a.checkTest("jo@gmail.com"))
#a.setApprovalDecline("john@gmail.com")
pt.dropPriceTable()