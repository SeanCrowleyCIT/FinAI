clients = [
    {
        'name': 'Corey Schafer',
        'email': 'test1@gmail.com',
        'phone': '08792828218',
        'isApproval': 'No',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'jane Doe',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'john Doe',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'Mary Doe',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'Hough Doe',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'John Smith',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'Sarah O&#39;Sullivan',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'Jim Carrey',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'Tom Cruise',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'Barney Stinson',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'name': 'Jack Murphy',
        'email': 'test2@gmail.com',
        'phone': '08762878218',
        'isApproval': 'Yes',
        'owner': 'susan.omahony@mycit.ie'
    }
    
]

#broker = "jordan.hennessy@mycit.ie.ie"

#a = ["jordan.hennessy@mycit.ie.ie"]
#b = {"aye":1, "bee":2, "cee":3, "dee":4, "eee":5}
#new_dict = dict((k, v) for k, v in clients[0].items() if v in a)
#print(new_dict)





   
   
current_user = 'jordan.hennessy@mycit.ie'
new_list = []
for i in clients:
    if i['owner'] == current_user:
        new_list.append(i)
print(new_list)















