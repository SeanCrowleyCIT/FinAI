import pyrebase
from flask_bcrypt import Bcrypt
config = {
  "apiKey": "AIzaSyBnMEwJ4cfyivrofIUb3EEC2qmmCU7oTHo",
  "authDomain": "fin-ai-50427.firebaseapp.com",
  "databaseURL": "https://fin-ai-50427.firebaseio.com",
  "storageBucket": "fin-ai-50427.appspot.com",
  "serviceAccount": "fin-ai-50427-firebase-adminsdk-vj6dm-c630798cad.json"
}

#https://github.com/thisbejim/Pyrebase

# get all data from table
firebase = pyrebase.initialize_app(config)
db = firebase.database()

#email = "admin@blog.com"
#all_users = db.child("brokers").get()
#for values in all_users.each():
#    if (values.val()["email"]==email): 
#        key = values.key()
#        db.child("brokers").child(key).remove()
password = "test"
hashed_password = Bcrypt.generate_password_hash(password).decode('utf-8')
print(hashed_password)