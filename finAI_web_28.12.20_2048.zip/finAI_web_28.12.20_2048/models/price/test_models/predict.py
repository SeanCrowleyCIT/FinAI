# Jordan Hennessy 
# 01/11/20
# jordan.hennessy@mycit.ie

import pandas as pd
import joblib
  
test = pd.read_csv("testFeatures.csv")   
real_price = test["price"][0]                 
print("Real Price: $ {:.2f}".format(real_price))

test = test.drop(['id', 'price', 'date'],axis=1)

#Pull previously saved model
loaded_model = joblib.load("train_models/finalized_model.sav")
# Make prediction with model
result = loaded_model.predict(test)[0]
print("Predicted price: $ {:.2f}".format(result))