function setQueueButtonStyle(sbutton)
{
	document.getElementById("client-button").className = "queue-button";
	document.getElementById("approval-button").className = "queue-button";
	
	document.getElementById(sbutton).className = "queue-button-focus";
}

function clientsButton()
{
	setQueueButtonStyle("client-button");
	document.getElementById("approval-table-area").style.display = "none";
	document.getElementById("client-table-area").style.display = "block";
}

function approvalsButton()
{
	setQueueButtonStyle("approval-button");
	document.getElementById("client-table-area").style.display = "none";
	document.getElementById("approval-table-area").style.display = "block";
}


window.onload = clientsButton();