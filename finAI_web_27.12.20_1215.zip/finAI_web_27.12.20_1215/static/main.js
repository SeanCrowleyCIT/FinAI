function setQueueButtonStyle(sbutton)
{
	document.getElementById("client-button").className = "queue-button";
	document.getElementById("approval-button").className = "queue-button";
	
	document.getElementById(sbutton).className = "queue-button-focus";
}

function clientsButton()
{
	setQueueButtonStyle("client-button");
}

function approvalsButton()
{
	setQueueButtonStyle("approval-button");
}


window.onload = setQueueButtonStyle("client-button");