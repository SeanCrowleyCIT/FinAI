#from flask import Flask, jsonify, request, redirect, url_for, render_template
#from flask_restful import Resource, Api, reqparse
#app = Flask(__name__)
#api = Api(app)
#import os
#pyrelist = []
#SECRET_KEY = os.urandom(32)
#app.config['SECRET_KEY'] = SECRET_KEY

import pyrebase
config = {
  "apiKey": "AIzaSyBnMEwJ4cfyivrofIUb3EEC2qmmCU7oTHo",
  "authDomain": "fin-ai-50427.firebaseapp.com",
  "databaseURL": "https://fin-ai-50427.firebaseio.com",
  "storageBucket": "fin-ai-50427.appspot.com",
  "serviceAccount": "fin-ai-50427-firebase-adminsdk-vj6dm-c630798cad.json"
}

#https://github.com/thisbejim/Pyrebase

# get all data from table
firebase = pyrebase.initialize_app(config)
db = firebase.database()


print("==============house_pricing table==============")
#print all data from house_pricing
myData = db.child("house_pricing").get()
print(myData.val())



print("==============Test: Select all Emails from house pricing==============")

#Print all emails from house pricing
for values in myData.each():
    print(values.val()["email"])

print("==============Test: Match on Email==============")

email = "jordan.hennessy@mycit.ie"

tempDic = {}

for values in myData.each():
    if (values.val()["email"]==email):
        print("Pass")
    else:
        print("Fail")
    
    #print(values.val()["email"])


print("\n")

print("==============Lending table==============")

#test loan forms

myloanData = db.child("loan_prediction").get()
print(myloanData.val())



print("==============Users table==============")

users = db.child("users").get()
print(users.val())

print("==============Brokers table==============")

users = db.child("brokers").get()
print(users.val())



