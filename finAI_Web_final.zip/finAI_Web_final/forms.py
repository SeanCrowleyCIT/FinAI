# Jordan Hennessy 
# 30/11/20
# jordan.hennessy@mycit.ie

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField, IntegerField, FloatField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo, InputRequired, ValidationError
from wtforms.fields.html5 import DateField
import pyrebase
config = {
  "apiKey": "AIzaSyBnMEwJ4cfyivrofIUb3EEC2qmmCU7oTHo",
  "authDomain": "fin-ai-50427.firebaseapp.com",
  "databaseURL": "https://fin-ai-50427.firebaseio.com",
  "storageBucket": "fin-ai-50427.appspot.com",
  "serviceAccount": "fin-ai-50427-firebase-adminsdk-vj6dm-c630798cad.json"
}

# initialize DB connection
firebase = pyrebase.initialize_app(config)
db = firebase.database()


#TO Do: login  in form

class LoginForm(FlaskForm):
    email = StringField('Email Address', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Sign in')
#TO Do: Register form
class RegisterForm(FlaskForm):
    email = StringField('Email Address', validators=[DataRequired(), Email()])
    password = PasswordField("Password", [DataRequired(), Length(min=4, max=20)])
    passwordConfirm = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password', message='Passwords must match')])
    submit = SubmitField('Register')
    
    def validate_email(self, email):
        user = emailExist(email.data, "brokers")
        print(user)
        if user:
            raise ValidationError('That email is taken. Please choose a different one.')

class HousingForm(FlaskForm):
    
    email = StringField('Email', validators=[DataRequired(), Email()])
    num_bedrooms = IntegerField('No. of bedrooms', validators=[InputRequired()])
    num_bathrooms = FloatField('No. of bathrooms', validators=[InputRequired()])
    num_floors = FloatField('No. of floors', validators=[DataRequired()])
    sqft_living_past = IntegerField('Sqft. living past', validators=[DataRequired()])
    sqft_lot_past = IntegerField('Sqft. lot past', validators=[DataRequired()])
    sqft_living_present = IntegerField('Sqft. living present', validators=[DataRequired()])
    sqft_lot_present = IntegerField('Sqft. lot present', validators=[DataRequired()])
    sqft_above = IntegerField('Sqft. Above', validators=[DataRequired()])
    sqft_basement = IntegerField('Sqft. basement', validators=[InputRequired()])
    zip_code = IntegerField('Zipcode', validators=[DataRequired()])
    latitude = FloatField('Latitude', validators=[DataRequired()])
    longitude = FloatField('Longitude', validators=[DataRequired()])
    waterfront = SelectField('Waterfront', validators=[DataRequired(), 
        Length(min=1)], choices=[('', ''), 
        ('1', 'Yes'), ('0', 'No')])
    view = SelectField('View', validators=[DataRequired()], 
        choices=[('', ''),('0', '0'), ('1', '1'), ('2', '2'), 
        ('3', '3'), ('4', '4')])
    condition = SelectField('Condition', validators=[DataRequired()], 
        choices=[('', ''),('1', '1'), ('2', '2'), ('3', '3'), 
        ('4', '4'), ('5', '5')])
    grade = SelectField('Grade', validators=[DataRequired()], 
        choices=[('', ''),('1', '1'), ('3', '3'), ('4', '4'), 
        ('5', '5'), ('6', '6'), ('7', '7'), ('8', '8'), ('9', '9'), ('10', '10'), 
        ('11', '11'), ('12', '12'), ('13', '13')])
    year_built = IntegerField('Year built', validators=[DataRequired()])
    year_renovated = IntegerField('Year renovated', validators=[InputRequired()])
    submit = SubmitField('Calculate')
    
class LendingForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    gender = SelectField('Gender', validators=[DataRequired(), 
        Length(min=1)], choices=[('', ''), 
        ('0', 'Male'), ('1', 'Female')])
    married = SelectField('Married', validators=[DataRequired(), 
        Length(min=1)], choices=[('', ''), 
        ('1', 'Yes'), ('0', 'No')])
    dependents = SelectField('Dependents', validators=[DataRequired()], 
        choices=[('', ''),('0', ' 0'), ('1', ' 1'), ('2', ' 2'), 
        ('3', '3+')])
    education = SelectField('Education', validators=[DataRequired(), 
        Length(min=1)], choices=[('', ''), 
        ('0', 'Graduate'), ('1', 'Not Graduate')])        
    Self_Employed = SelectField('Self employed', validators=[DataRequired(), 
        Length(min=1)], choices=[('', ''), 
        ('1', 'Yes'), ('0', 'No')])
    ApplicantIncome = IntegerField('Applicant Income', validators=[InputRequired()])
    CoapplicantIncome = IntegerField('Coapplicant Income', validators=[InputRequired()])
    LoanAmount = IntegerField('Loan Amount', validators=[DataRequired()])
    Loan_Amount_Term = IntegerField('Term', validators=[DataRequired()])
    Credit_History = SelectField('Credit History', validators=[DataRequired(), 
        Length(min=1)], choices=[('', ''), 
        ('1', 'Yes'), ('0', 'No')])
    Property_Area = SelectField('Property Area', validators=[DataRequired()], 
        choices=[('', ''),('0', 'Urban'), ('1', 'Rural'), ('2', 'Semi-urban')])
    submit = SubmitField('Calculate')
    
    
def emailExist(email, table):
        isEmail = False
        all_users = db.child(table).get()
        try:
            for values in all_users.each():
                if (values.val()["email"]==email):  
                    isEmail = True
                    return isEmail
        except:
            print("An error occurred iterating over an empty dictionary.")
        return isEmail