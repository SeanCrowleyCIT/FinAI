import pyrebase
from flask_bcrypt import Bcrypt
from flask import Flask
config = {
  "apiKey": "AIzaSyBnMEwJ4cfyivrofIUb3EEC2qmmCU7oTHo",
  "authDomain": "fin-ai-50427.firebaseapp.com",
  "databaseURL": "https://fin-ai-50427.firebaseio.com",
  "storageBucket": "fin-ai-50427.appspot.com",
  "serviceAccount": "fin-ai-50427-firebase-adminsdk-vj6dm-c630798cad.json"
}

# initialize DB connection
firebase = pyrebase.initialize_app(config)
db = firebase.database()


#-----Tables / Listed Dictionary Lables -----
broker_table = "brokers"
users_table = "users"

class Broker():
    #Checks if the broker email exists for validation
    def isBroker(email):
        return emailExist(email, broker_table)

    def addBroker(email, password):
        addusers(email, password, broker_table)
        
    def removeBroker(email):
        removeUser(email, broker_table)
    
    def dropBroker(email):
        print(email)
        removeUser(email, broker_table)
        





def emailExist(email, table):
        isEmail = False
        all_users = db.child(table).get()
        for values in all_users.each():
            if (values.val()["email"]==email):  
                isEmail = True
        return isEmail
        
def addusers(email, password, table):
    token = email
    newUser = {"email": email, "password": password}
    db.child(table).push(newUser)
    
def removeUser(email, table):
    print("2 : ", email)
    key = getKey(email, table)
    print(key)
    db.child(table).child(key).remove()
 
def dropTable(email, table):
    all_users = db.child(table).get()
    for values in all_users.each():
        if (values.val()["email"]==email): 
            key = values.key()
            db.child(table).child(key).remove()

 
    
def getKey(email, table):
    key = ""
    all_users = db.child(table).get()
    try:
        for values in all_users.each():
            if (values.val()["email"]==email): 
                key = values.key()
            return key
    except:
        print("Empty dictionary.")
    
    
    
    