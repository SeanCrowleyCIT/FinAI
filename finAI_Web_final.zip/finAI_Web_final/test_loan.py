from predict_loan import PredictLoan

mlist = [0, 1, 0, 0, 1, 500, 300, 6, 360, 0, 0]
loan_prediction = PredictLoan(mlist)
loan = loan_prediction.get_eligibility()
print(loan)