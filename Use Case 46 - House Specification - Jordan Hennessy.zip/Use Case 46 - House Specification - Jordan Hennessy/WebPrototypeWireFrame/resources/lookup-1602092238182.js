(function(window, undefined) {
  var dictionary = {
    "c97ec82c-b251-4fff-8f16-aa4fdb407d87": "Client Requests - Client",
    "69ffa8d8-fc74-4167-8208-5de5d073b4a0": "Lending - Not Approved",
    "fdbca0b4-405c-4bc4-9271-6a87b5ff45f2": "Lending - Process Payment",
    "5a6f1dc9-ecf7-4704-b330-c586490e7d61": "Housing",
    "a0f68486-a99c-4028-bdc3-56cafc0e9db4": "Lending - Approved",
    "206a1105-44d6-4832-b89c-46d783afef88": "Lending",
    "63f61824-6d8c-4c42-94dc-f8687ebdf70d": "Client Requests",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login / Register",
    "2ff5c412-2db7-4ebd-a664-8d993b404c64": "Client Requests - Requests",
    "408399bf-18dc-4fd2-b63a-5f0266779bf6": "Reporting",
    "dd8eee09-39d6-4e18-941b-5b71a18b9b13": "Register",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);