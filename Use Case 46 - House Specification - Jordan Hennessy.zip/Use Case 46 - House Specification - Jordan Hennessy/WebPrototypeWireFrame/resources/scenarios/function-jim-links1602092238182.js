(function(window, undefined) {

  var jimLinks = {
    "c97ec82c-b251-4fff-8f16-aa4fdb407d87" : {
      "Rectangle_2" : [
        "408399bf-18dc-4fd2-b63a-5f0266779bf6"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ],
      "Rectangle_4" : [
        "5a6f1dc9-ecf7-4704-b330-c586490e7d61"
      ],
      "Rectangle_12" : [
        "63f61824-6d8c-4c42-94dc-f8687ebdf70d"
      ]
    },
    "69ffa8d8-fc74-4167-8208-5de5d073b4a0" : {
      "Rectangle_2" : [
        "408399bf-18dc-4fd2-b63a-5f0266779bf6"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ]
    },
    "fdbca0b4-405c-4bc4-9271-6a87b5ff45f2" : {
      "Rectangle_2" : [
        "408399bf-18dc-4fd2-b63a-5f0266779bf6"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ],
      "Rectangle_53" : [
        "a0f68486-a99c-4028-bdc3-56cafc0e9db4"
      ]
    },
    "5a6f1dc9-ecf7-4704-b330-c586490e7d61" : {
      "Rectangle_2" : [
        "408399bf-18dc-4fd2-b63a-5f0266779bf6"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ],
      "Rectangle_14" : [
        "fdbca0b4-405c-4bc4-9271-6a87b5ff45f2"
      ]
    },
    "a0f68486-a99c-4028-bdc3-56cafc0e9db4" : {
      "Rectangle_2" : [
        "408399bf-18dc-4fd2-b63a-5f0266779bf6"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ],
      "Rectangle_43" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ]
    },
    "206a1105-44d6-4832-b89c-46d783afef88" : {
      "Rectangle_1" : [
        "63f61824-6d8c-4c42-94dc-f8687ebdf70d"
      ],
      "Rectangle_2" : [
        "408399bf-18dc-4fd2-b63a-5f0266779bf6"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ],
      "Rectangle_4" : [
        "5a6f1dc9-ecf7-4704-b330-c586490e7d61"
      ],
      "Rectangle_39" : [
        "fdbca0b4-405c-4bc4-9271-6a87b5ff45f2"
      ]
    },
    "63f61824-6d8c-4c42-94dc-f8687ebdf70d" : {
      "Rectangle_2" : [
        "408399bf-18dc-4fd2-b63a-5f0266779bf6"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ],
      "Rectangle_4" : [
        "5a6f1dc9-ecf7-4704-b330-c586490e7d61"
      ],
      "Text_cell_21" : [
        "2ff5c412-2db7-4ebd-a664-8d993b404c64"
      ],
      "Text_cell_54" : [
        "c97ec82c-b251-4fff-8f16-aa4fdb407d87"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "63f61824-6d8c-4c42-94dc-f8687ebdf70d"
      ],
      "Button_2" : [
        "dd8eee09-39d6-4e18-941b-5b71a18b9b13"
      ]
    },
    "2ff5c412-2db7-4ebd-a664-8d993b404c64" : {
      "Rectangle_2" : [
        "408399bf-18dc-4fd2-b63a-5f0266779bf6"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ],
      "Rectangle_4" : [
        "5a6f1dc9-ecf7-4704-b330-c586490e7d61"
      ],
      "Rectangle_8" : [
        "63f61824-6d8c-4c42-94dc-f8687ebdf70d"
      ],
      "Rectangle_11" : [
        "63f61824-6d8c-4c42-94dc-f8687ebdf70d"
      ],
      "Rectangle_12" : [
        "63f61824-6d8c-4c42-94dc-f8687ebdf70d"
      ]
    },
    "408399bf-18dc-4fd2-b63a-5f0266779bf6" : {
      "Rectangle_1" : [
        "63f61824-6d8c-4c42-94dc-f8687ebdf70d"
      ],
      "Rectangle_3" : [
        "206a1105-44d6-4832-b89c-46d783afef88"
      ],
      "Rectangle_4" : [
        "5a6f1dc9-ecf7-4704-b330-c586490e7d61"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);