var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-dd8eee09-39d6-4e18-941b-5b71a18b9b13" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Register" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/dd8eee09-39d6-4e18-941b-5b71a18b9b13-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/dd8eee09-39d6-4e18-941b-5b71a18b9b13-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/dd8eee09-39d6-4e18-941b-5b71a18b9b13-1602092238182-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="394.5px" datasizeheight="562.0px" datasizewidthpx="394.4999999999998" datasizeheightpx="562.0" dataX="751.0" dataY="27.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="347.0px" datasizeheight="32.0px" datasizewidthpx="347.0" datasizeheightpx="32.00000000000006" dataX="774.7" dataY="66.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_1" customid="Line 2" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="357.0px" datasizeheight="3.0px" datasizewidthpx="357.0" datasizeheightpx="3.0" dataX="769.8" dataY="422.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 1.5 L 357.0 1.5"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer commentable non-processed" customid="Button 1"   datasizewidth="340.3px" datasizeheight="40.0px" dataX="778.1" dataY="354.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Register</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="220.0px" datasizeheight="30.0px" dataX="789.5" dataY="67.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Name" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="314.0px" datasizeheight="115.0px" dataX="791.3" dataY="463.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/797ca04e-d69f-4e3d-b318-af4c0ac79b9c.png" />\
        	</div>\
        </div>\
      </div>\
\
\
        <div id="s-Radio_button_1" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 1" datasizewidth="13.0px" datasizeheight="13.0px" dataX="821.6" dataY="315.0" >\
          <input class="radioButtonInput" type="radio"    value="true"  checked="checked" tabindex="-1" >\
        </div>\
\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 10"   datasizewidth="71.0px" datasizeheight="41.0px" datasizewidthpx="71.00000000000023" datasizeheightpx="41.00000000000017" dataX="852.6" dataY="301.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Banker</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
        <div id="s-Radio_button_2" class="radiobutton firer commentable non-processed nonMobile" customid="Radio button 2" datasizewidth="13.0px" datasizeheight="13.0px" dataX="963.6" dataY="315.0" >\
          <input class="radioButtonInput" type="radio"       tabindex="-1" >\
        </div>\
\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 10"   datasizewidth="71.0px" datasizeheight="41.0px" datasizewidthpx="71.00000000000023" datasizeheightpx="41.00000000000017" dataX="1003.9" dataY="301.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0">Broker</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="347.0px" datasizeheight="32.0px" datasizewidthpx="347.0" datasizeheightpx="32.00000000000006" dataX="774.7" dataY="111.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="220.0px" datasizeheight="30.0px" dataX="789.5" dataY="112.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Last name" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="347.0px" datasizeheight="32.0px" datasizewidthpx="347.0" datasizeheightpx="32.00000000000006" dataX="774.7" dataY="155.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="220.0px" datasizeheight="30.0px" dataX="789.5" dataY="156.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Email address" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="347.0px" datasizeheight="32.0px" datasizewidthpx="347.0" datasizeheightpx="32.00000000000006" dataX="774.7" dataY="197.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_4" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="220.0px" datasizeheight="30.0px" dataX="789.5" dataY="198.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Password" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_8" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="347.0px" datasizeheight="32.0px" datasizewidthpx="347.0" datasizeheightpx="32.00000000000006" dataX="774.7" dataY="240.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_5" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="220.0px" datasizeheight="30.0px" dataX="789.5" dataY="241.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Confirm password" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_9" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 3"   datasizewidth="68.0px" datasizeheight="59.0px" datasizewidthpx="68.0" datasizeheightpx="59.00000000000009" dataX="914.3" dataY="422.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_9_0">OR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="256.0px" datasizeheight="210.0px" dataX="177.0" dataY="43.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3ed46cae-54a5-4a89-b668-4607ef4a2c31.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_10" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 4"   datasizewidth="283.0px" datasizeheight="127.0px" datasizewidthpx="283.0" datasizeheightpx="127.0" dataX="257.0" dataY="166.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_10_0">Fin - AI helps you calculate house prices and eligibility for lending aided by intelligent design.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;