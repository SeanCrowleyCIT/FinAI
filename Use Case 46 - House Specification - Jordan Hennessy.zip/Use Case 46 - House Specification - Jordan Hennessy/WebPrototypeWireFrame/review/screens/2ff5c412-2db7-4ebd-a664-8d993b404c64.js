var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-2ff5c412-2db7-4ebd-a664-8d993b404c64" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Client Requests - Requests" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/2ff5c412-2db7-4ebd-a664-8d993b404c64-1602092238182.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/2ff5c412-2db7-4ebd-a664-8d993b404c64-1602092238182-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/2ff5c412-2db7-4ebd-a664-8d993b404c64-1602092238182-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="175.0px" datasizeheight="128.0px" dataX="-1.5" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3ed46cae-54a5-4a89-b668-4607ef4a2c31.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Line_1" customid="Line 1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="1100.0px" datasizeheight="2.0px" datasizewidthpx="1100.0" datasizeheightpx="2.0" dataX="61.5" dataY="111.0" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 1" d="M 0.0 1.0 L 1100.0 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="186.0" datasizeheightpx="95.99999999999994" dataX="257.0" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0">Clients</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="439.0" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0">Reporting</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="611.5" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0">Lending</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 1"   datasizewidth="186.0px" datasizeheight="96.0px" datasizewidthpx="185.9999999999999" datasizeheightpx="95.99999999999996" dataX="797.5" dataY="16.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0">Housing</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="228.5px" datasizeheight="42.0px" datasizewidthpx="228.45505941742408" datasizeheightpx="42.00000000000014" dataX="1051.5" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">Jordan</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Triangle_1" customid="Triangle 1" class="shapewrapper shapewrapper-s-Triangle_1 non-processed"  rotationdeg="180" datasizewidth="19.0px" datasizeheight="15.0px" datasizewidthpx="19.0" datasizeheightpx="15.0" dataX="1201.5" dataY="16.0" originalwidth="19.0px" originalheight="15.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Triangle_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Triangle_1)">\
                          <path id="s-Triangle_1" class="pie triangle shape non-processed-shape manualfit firer commentable non-processed" customid="Triangle 1" d="M 9.0 0.0 L 19.0 15.0 L 0.0 15.0 Z">\
                          </path>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Triangle_1" class="clipPath">\
                          <path d="M 9.0 0.0 L 19.0 15.0 L 0.0 15.0 Z">\
                          </path>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Triangle_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Triangle_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 7"   datasizewidth="1197.0px" datasizeheight="1136.0px" datasizewidthpx="1197.0" datasizeheightpx="1136.0" dataX="26.5" dataY="84.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_2" customid="Line 2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="1159.1px" datasizeheight="1.0px" datasizewidthpx="1159.0898811651527" datasizeheightpx="1.0" dataX="45.4" dataY="232.4" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 2" d="M 0.0 0.5 L 1159.0898811651527 0.5"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_3" customid="Line 3" class="shapewrapper shapewrapper-s-Line_3 non-processed"  rotationdeg="90" datasizewidth="101.1px" datasizeheight="1.0px" datasizewidthpx="101.11215127266087" datasizeheightpx="1.0" dataX="408.4" dataY="282.4" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 3" d="M 0.0 0.5 L 101.11215127266087 0.5"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_4" customid="Line 4" class="shapewrapper shapewrapper-s-Line_4 non-processed"  rotationdeg="90" datasizewidth="97.0px" datasizeheight="1.0px" datasizewidthpx="97.0" datasizeheightpx="1.0" dataX="858.5" dataY="284.5" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 4" d="M 0.0 0.5 L 97.0 0.5"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 8"   datasizewidth="336.0px" datasizeheight="145.0px" datasizewidthpx="336.0" datasizeheightpx="145.0" dataX="919.7" dataY="212.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0">Status: Open<br />Risk: </span><span id="rtr-s-Rectangle_7_1">High<br /></span><span id="rtr-s-Rectangle_7_2">Payment Outstanding: $0.00<br />Creation Date: 06.10.20</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_5" customid="Line 5" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="1190.0px" datasizeheight="2.0px" datasizewidthpx="1189.9550594174239" datasizeheightpx="2.0" dataX="30.6" dataY="332.5" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_5" class="pie line shape non-processed-shape firer ie-background commentable non-processed" customid="Line 5" d="M 0.0 1.0 L 1189.9550594174239 1.0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_8" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 12"   datasizewidth="172.0px" datasizeheight="49.2px" datasizewidthpx="172.0" datasizeheightpx="49.22430254532185" dataX="59.3" dataY="154.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0">Back</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_9" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 13"   datasizewidth="239.0px" datasizeheight="61.0px" datasizewidthpx="239.0" datasizeheightpx="61.0" dataX="61.5" dataY="247.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_9_0">Customer<br />John Doe</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_10" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 13"   datasizewidth="319.0px" datasizeheight="61.0px" datasizewidthpx="319.00000000000017" datasizeheightpx="61.0" dataX="508.0" dataY="254.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_10_0">Request: Loan Eligibility</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_11" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 12"   datasizewidth="172.0px" datasizeheight="49.2px" datasizewidthpx="172.0" datasizeheightpx="49.22430254532185" dataX="468.0" dataY="344.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_11_0">Approve</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_12" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle 12"   datasizewidth="172.0px" datasizeheight="49.2px" datasizewidthpx="172.0" datasizeheightpx="49.22430254532185" dataX="718.0" dataY="344.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_12_0">Deny</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_13" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="51.0" dataY="461.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_13_0">First Name:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer ie-background commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="243.0" dataY="459.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="John"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_14" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="587.5" dataY="461.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_14_0">Last Name:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="pie text firer ie-background commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="816.0" dataY="459.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Doe"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_15" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="37.0" dataY="548.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_15_0">Address:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="243.0" dataY="546.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Apartment 4, Patrick street, Cork City"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_16" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="593.0" dataY="548.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_16_0">Date of birth: </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_4" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="816.0" dataY="546.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="01.04.84"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_17" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="42.7" dataY="633.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_17_0">Married: </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_5" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="243.0" dataY="631.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Yes"/></div></div>  </div></div></div>\
      <div id="s-Input_6" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="816.0" dataY="631.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Male"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_18" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="570.0" dataY="633.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_18_0">Gender:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_7" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="243.0" dataY="712.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Not Graduated"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_19" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="45.4" dataY="714.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_19_0">Education: </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_8" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="816.0" dataY="712.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Yes"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_20" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="593.0" dataY="714.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_20_0">Self employed:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_9" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="243.0" dataY="794.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="6"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_21" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="45.4" dataY="796.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_21_0">Dependents:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_10" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="816.0" dataY="794.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="$26,000"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_22" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="601.0" dataY="796.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_22_0">Applicant income:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_11" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="243.0" dataY="875.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="$0.00"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_23" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="49.0px" datasizewidthpx="234.0" datasizeheightpx="49.0" dataX="37.0" dataY="871.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_23_0">Coapplicant <br />income:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_12" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="816.0" dataY="875.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="$20,000"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_24" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="563.5" dataY="877.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_24_0">Amount: </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_13" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="243.0" dataY="956.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="365"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_25" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="26.5" dataY="958.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_25_0">Term: </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_14" class="pie text firer commentable non-processed" customid="Input 1"  datasizewidth="311.0px" datasizeheight="41.0px" dataX="816.0" dataY="956.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Urban"/></div></div>  </div></div></div>\
      <div id="s-Rectangle_26" class="pie rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="234.0px" datasizeheight="37.0px" datasizewidthpx="234.0" datasizeheightpx="37.0" dataX="570.0" dataY="958.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_26_0">Property: </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;