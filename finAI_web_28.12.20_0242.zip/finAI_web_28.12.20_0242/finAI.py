# Jordan Hennessy 
# 30/11/20
# jordan.hennessy@mycit.ie

from flask import Flask, render_template, url_for, flash, redirect, session
from forms import HousingForm, LendingForm, LoginForm, RegisterForm
from predict_price import PredictPrice
from predict_loan import PredictLoan
from flask_bcrypt import Bcrypt
from data import Users, Clients, Loan_Table, Price_Table, Broker, Approval
from functools import wraps
import pyrebase
import os
app = Flask(__name__)
SECRET_KEY = os.urandom(32)
app.config['SECRET_KEY'] = SECRET_KEY
bcrypt = Bcrypt(app)
config = {
  "apiKey": "AIzaSyBnMEwJ4cfyivrofIUb3EEC2qmmCU7oTHo",
  "authDomain": "fin-ai-50427.firebaseapp.com",
  "databaseURL": "https://fin-ai-50427.firebaseio.com",
  "storageBucket": "fin-ai-50427.appspot.com",
  "serviceAccount": "fin-ai-50427-firebase-adminsdk-vj6dm-c630798cad.json"
}
# initialize DB connection
firebase = pyrebase.initialize_app(config)
db = firebase.database()
#auth instance
auth = firebase.auth()

lt = Loan_Table
pt = Price_Table
apr = Approval
b = Broker
cl = Clients
#To cleanse tables of bad data while testing

#lt.dropLoanTable()
#pt.dropPriceTable()
#b.dropBrokerTable()
#cl.dropClientTable()

clients = [
    {
        'customer_name': 'Corey Schafer',
        'customer_email': 'test1@gmail.com',
        'customer_contact': '08792828218',
        'isApproval': 'No',
        'owner': 'jordan.hennessy@mycit.ie',
        'owner' : 'Jordan Hennessy'
    },
    {
        'customer_name': 'jane Doe',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'john Doe',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'Mary Doe',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'Hough Doe',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'John Smith',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'Sarah OSullivan',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'Jim Carrey',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'Tom Cruise',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'Barney Stinson',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'jordan.hennessy@mycit.ie'
    },
    {
        'customer_name': 'Jack Murphy',
        'customer_email': 'test2@gmail.com',
        'customer_contact': '08762878218',
        'isApproval': 'Yes',
        'owner': 'susan.omahony@mycit.ie'
    }
    
]


# decorator to protect routes
# Stop user accessing page without being authenticated.
def isAuthenticated(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        #check for the variable that pyrebase creates
        if not auth.current_user != None:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        # get the request data
        email = form.data["email"]
        password = form.data["password"]
        try:
            # login the user
            user = auth.sign_in_with_email_and_password(email, password)
            # set the session
            user_id = user['idToken']
            user_email = email
            session['usr'] = user_id
            # To be used later to pull user relevant data
            session["email"] = user_email
            return redirect(url_for('home'))  
          
        except:
            return render_template("login.html", message="Your email address or password is incorrect.", form=form)  

     
    return render_template("login.html", form=form)


#Register route
@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
      #get the request form data
      email = form.data["email"]
      password = form.data["password"]
      try:
        #create the user
        auth.create_user_with_email_and_password(email, password);
        #This table will be used later in our forms as validation to ensure the data is attached to an existing broker
        b.addBroker(email)
        return redirect(url_for('login'))
      except Exception as e:
        print(e)
        return render_template("register.html", message="That email is taken. Please choose a different one.", form=form)  
    return render_template("register.html", form=form)



#logout route
@app.route("/logout")
@isAuthenticated
def logout():
    #remove the token setting the user to None
    auth.current_user = None
    #also remove the session
    session.clear()
    return redirect("/");


@app.route('/clients')
@app.route('/approvals')
@app.route('/home')
@isAuthenticated
def home():
    #TO DO: Get the current user that is logged in email 
    # Make it a global variable
    current_user = 'jordan.hennessy@mycit.ie'
    
    #client_list = []
    #approval_list = []
    #for i in clients:
    #    if i['owner'] == current_user:
    #        approval_list.append(i)
    client_list = cl.getClientList(session["email"])
    print(client_list)
    approval_list = apr.getApprovalList(session["email"])
    return render_template('home.html', title="Home", clients=client_list, approval=approval_list)
    
@app.route("/reporting")
@isAuthenticated
def reporting():
    return render_template('reporting.html', title="Reporting")

@app.route("/lending", methods=['GET', 'POST'])
@isAuthenticated
def lending():
    form = LendingForm()
    lending_model_data = []
    dict_for_db = {}
    if form.validate_on_submit():
        # Add dictionary values to list in the order machine learning
        # script will expect    
        lending_model_data.append(form.data["gender"])
        lending_model_data.append(form.data["married"])
        lending_model_data.append(form.data["dependents"])
        lending_model_data.append(form.data["education"])
        lending_model_data.append(form.data["Self_Employed"])
        lending_model_data.append(form.data["ApplicantIncome"])
        lending_model_data.append(form.data["CoapplicantIncome"])
        lending_model_data.append(form.data["LoanAmount"])
        lending_model_data.append(form.data["Loan_Amount_Term"])
        lending_model_data.append(form.data["Credit_History"])
        lending_model_data.append(form.data["Property_Area"])
              
        
        #Pass the list to the prediction script
        loan_prediction = PredictLoan(lending_model_data)
        loan = loan_prediction.get_eligibility()

        #Create a client if they don't exist already
        #addClient(customer_name, customer_email, customer_contact, owner)
        cl.addClient(form.data["name"], form.data["client_email"], form.data["telephone"], form.data["email"])
        
        dict_for_db = form.data
        
        #Remove data we don't need in our loan tables
        dict_for_db.pop("name")
        dict_for_db.pop("telephone")  
        
        # Append loan eligibility answer to our dictionary of items before pushing to db
        dict_for_db["isEligible"] = loan
        
        # Approval states:
        #   1. Pending (default)
        #   2. closed - either overwritten by client creating new approval or manually set to close by admin
        #   3. Approved
        #   4. Declined
        #These methods are used to open and close tickets (approvals) for our ticketing system
        #Rules:
            # 1. These methods are only to be used in our approvals table.
            # 2. Status can only go from pending > Closed, pending > Approved, pending > Declined 
            # 3. isApproval will always be 'Pending' on creation and then updated to either closed | approved | declined.
            # 4. isApproval can only be made 'Declined' | 'Approved' onClick of button on Approval page by banking professional.
            # 5. There can only be one approval per customer email at a time.
            # 6. Creating a new approval pushes the old approval to 'loan_prediction' table in db, then overwrites the old approval with new approval.
        
        #Append our default approval status 
        dict_for_db["isApproval"] = "Pending"
        
        #TO DO: Capture banking professional id so clients can be captured later
        
        # Push input data to db
        #db.child("loan_prediction").push(dict_for_db)
        apr.addApproval(dict_for_db)
        
         
        #Reload lending page with predicted eligibility
        return render_template('lending.html', form=form, loan=loan, title="Lending")
    return render_template('lending.html', form=form, title="Lending")
    
@app.route("/housing", methods=['GET', 'POST'])
@isAuthenticated
def housing():
    form = HousingForm()
    pricing_model_data = []
    dict_for_db = {}
    if form.validate_on_submit():
        #Add dictionary values to list in the order machine learning
        # script will expect    
        pricing_model_data.append(form.data["num_bedrooms"])
        pricing_model_data.append(form.data["num_bathrooms"])
        pricing_model_data.append(form.data["sqft_living_past"])
        pricing_model_data.append(form.data["sqft_lot_past"])
        pricing_model_data.append(form.data["num_floors"])
        pricing_model_data.append(form.data["waterfront"])
        pricing_model_data.append(form.data["view"])
        pricing_model_data.append(form.data["condition"])
        pricing_model_data.append(form.data["grade"])
        pricing_model_data.append(form.data["sqft_above"])
        pricing_model_data.append(form.data["sqft_basement"])
        pricing_model_data.append(form.data["year_built"])
        pricing_model_data.append(form.data["year_renovated"])
        pricing_model_data.append(form.data["zip_code"])
        pricing_model_data.append(form.data["latitude"])
        pricing_model_data.append(form.data["longitude"])
        pricing_model_data.append(form.data["sqft_living_present"])
        pricing_model_data.append(form.data["sqft_lot_present"])
        
        #Pass the list to the prediction script
        price_prediction = PredictPrice(pricing_model_data)
        price = "{:20,.2f}".format(price_prediction.get_price())
        
        #Create a client if they don't exist already
        #addClient(customer_name, customer_email, customer_contact, owner)
        cl.addClient(form.data["name"], form.data["client_email"], form.data["telephone"], form.data["email"])

        dict_for_db = form.data
        #Remove data we don't need in our hour house_pricing table
        dict_for_db.pop("name")
        dict_for_db.pop("telephone")        
        # Append price to our dictionary of items before pushing to db
        dict_for_db["price"] = price
        
        # Push input data to db
        db.child("house_pricing").push(dict_for_db)
         
         #Reload housing page with predicted price
        return render_template('housing.html', form=form, price=price, title="Housing")
    return render_template('housing.html', form=form, title="Housing")
 
@app.route("/account")
@isAuthenticated
def account():
    return render_template('account.html', title="Account")
    
@app.route("/payment")
@isAuthenticated
def payment():
    return render_template('payment.html', title="Payment")
    
    
@app.route("/chatbot")
@isAuthenticated
def get_bot_response():

    form = chatbotForm()
    data = "null"
    if form.validate_on_submit():
        return render_template('chatbot2.html',form=form, data="looky here!")
        chatbot = ChatBot(
        'FinAIBot',
        trainer='chatterbot.trainers.ListTrainer'
        )
        print ("chatbot form running!")
        sys.stdout.flush()
	 #request.args is gets a "dictionary" object for you. The "dictionary" object is similar to other collection-type of objects in Python, in that it
	# can store many elements in one single object. It takes one parameter, one object, a "dictionary" type of object. This "dictionary" object, however, can
	# have as many elements as needed.
        userText = form.data["question"]
        data = chatbot.get_response(userText)
    else:
        return render_template('chatbot2.html',form=form, data="no validation!")
    return render_template('chatbot2.html', form=form)
    
    

if __name__ == '__main__':
    app.run(debug=True)