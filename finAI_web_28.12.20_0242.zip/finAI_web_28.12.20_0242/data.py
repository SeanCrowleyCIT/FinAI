import pyrebase
from flask_bcrypt import Bcrypt
from flask import Flask

config = {
  "apiKey": "AIzaSyBnMEwJ4cfyivrofIUb3EEC2qmmCU7oTHo",
  "authDomain": "fin-ai-50427.firebaseapp.com",
  "databaseURL": "https://fin-ai-50427.firebaseio.com",
  "storageBucket": "fin-ai-50427.appspot.com",
  "serviceAccount": "fin-ai-50427-firebase-adminsdk-vj6dm-c630798cad.json"
}

# initialize DB connection
firebase = pyrebase.initialize_app(config)
db = firebase.database()


#-----Tables / Listed Dictionary Labels -----

# Holds our brokers - used as validation on forms to make sure we are 
# Connecting clients to existing brokers
# Separate from our table that holds password and email
broker_table = "brokers"

#Holds our user (app) email and password
# To do: 
    # 1. Implement built in firebase auth to handle this table
users_table = "users"

# Will hold our approvals for our ticketing system
approval_table = "approvals"

# Will hold our approvals that have been actioned
# Essentially this table is a historic record with little manipulation as it will mostly be read only
loan_table = "loan_prediction"

# Will hold pricing requests
price_table = "house_pricing"

# Hold our clients data
client_table = "clients"

# This the set once of fee for consultation services
# To be appended to the client 
consultation_fee = 70.00

class Users():
    #Checks if the user email exists for validation
    def isUser(email):
        return emailExist(email, users_table)

    def addUser(email, password):
        addusers(email, password, users_table)
        
    def removeUser(email):
        removeUser(email, users_table)
        
    def dropUserTable(email):
        dropTable(users_table)

class Approval():
    def approvalExist(customer_email):
        return approvalExist(email)
        
    # 1. Check if there is an existing approval
    # 2. If exists 
        # a. then change isApproval status to closed and push it to loan_table
        # b. Remove current approval
        # c. Add new approval
    # 3. If not exist
        # a. Add new approval
    def addApproval(form):
        email = form["client_email"]
        customer_email_str = email.replace(".", ",")
        if approvalExist(email):
            db.child(approval_table).child(customer_email_str).update({"isApproval": "Closed"})
            copy_current_approval = db.child(approval_table).child(customer_email_str).get()
            db.child(loan_table).push(copy_current_approval.val())
            db.child(approval_table).child(customer_email_str).remove()
            db.child(approval_table).child(customer_email_str).set(form)
        else:
            db.child(approval_table).child(customer_email_str).set(form)
            
    # Approval states:
    #   1. Pending (default)
    #   2. closed - either overwritten by client creating new approval or manually set to close by admin
    #   3. Approved
    #   4. Declined
    #These methods are used to open and close tickets (approvals) for our ticketing system
    #Rules:
        # 1. These methods are only to be used in our approvals table.
        # 2. Status can only go from pending > Closed, pending > Approved, pending > Declined 
        # 3. isApproval will always be 'Pending' on creation and then updated to either closed | approved | declined.
        # 4. isApproval can only be made 'Declined' | 'Approved' onClick of button on Approval page by banking professional.
        # 5. There can only be one approval per customer email at a time.
        # 6. Creating a new approval pushes the old approval to 'loan_prediction' table in db, then overwrites the old approval with new approval.

    # Change isApproval status to closed and push record to loan_table
    def setApprovalClosed(email):
        customer_email_str = email.replace(".", ",")
        db.child(approval_table).child(customer_email_str).update({"isApproval": "Closed"})
        copy_current_approval = db.child(approval_table).child(customer_email_str).get()
        db.child(loan_table).push(copy_current_approval.val())
        db.child(approval_table).child(customer_email_str).remove()
        
    # Change isApproval status to Declined and push record to loan_table
    def setApprovalDecline(email):
        customer_email_str = email.replace(".", ",")
        db.child(approval_table).child(customer_email_str).update({"isApproval": "Declined"})
        copy_current_approval = db.child(approval_table).child(customer_email_str).get()
        db.child(loan_table).push(copy_current_approval.val())
        db.child(approval_table).child(customer_email_str).remove()
        
    # Change isApproval status to Approved and push record to loan_table           
    def setApprovalApprove(email):
        customer_email_str = email.replace(".", ",")
        db.child(approval_table).child(customer_email_str).update({"isApproval": "Approved"})
        copy_current_approval = db.child(approval_table).child(customer_email_str).get()
        db.child(loan_table).push(copy_current_approval.val())
        db.child(approval_table).child(customer_email_str).remove()
    
    #remove all elements in loan_table
    def dropLoanTable():
        dropTable(loan_table)
        
    #remove all elements in approve_table    
    def dropApprovalTable():
        dropTable(approval_table)
    
    #Return approval values
    def getApproval(email):
        customer_email_str = email.replace(".", ",")
        approval = db.child(approval_table).child(customer_email_str).get()
        return(approval.val())
        
    #List of approvals owned by broker
    def getApprovalList(email):
        approval_list = []
        approvals = db.child(approval_table).get()
        try:
            for values in approvals.each():
                if (values.val()["email"]==email):
                    approval_list.append(values.val()) 
        except:
            print("data.py -> Approval -> getApprovalList: Empty table error.")
                
        return approval_list
        
            

class Clients():
    def isClient(email):
        return clientExist(email)
        
    # Add the client info if they don't already exist 
    # Client will be created with the consultation_fee as 70.00            
    def addClient(customer_name, customer_email, customer_contact, owner):
        if not clientExist(customer_email):
            newClient = {"customer_name": customer_name, "customer_email": customer_email, "customer_contact": customer_contact, "owner": owner, "fee": consultation_fee}
            #To handle issue where firebase doesn't allow '.' in their keys
            customer_email_str = customer_email.replace(".", ",")
            db.child(client_table).child(customer_email_str).set(newClient)
            
                
    def dropClientTable():
        dropTable(client_table)
        
    def removeClient(email):
        customer_email_str = email.replace(".", ",")
        db.child(client_table).child(customer_email_str).remove()
        
    def getClientKey(email):
        customer_email_str = email.replace(".", ",")
        return customer_email_str
    
    #List of clients owned by broker
    def getClientList(email):
        client_list = []
        clients = db.child(client_table).get()
        try:
            for values in clients.each():
                if (values.val()["owner"]==email):
                    client_list.append(values.val()) 
        except:
            print("data.py - Clients - getClientList: Empty table error.")   
        return client_list
        
                
class Loan_Table():
    def dropLoanTable():
        dropTable(loan_table)
                
class Price_Table():
    def dropPriceTable():
        dropTable(price_table)
        
class Broker():
    def addBroker(email):
        newUser = {"email": email}
        db.child(broker_table).push(newUser)
    def removeBroker(email):
        removeUser(email, broker_table)
    def dropBrokerTable():
        dropTable(broker_table)
    def isBroker(email):
        return emailExist(email, broker_table)
        
        
        

def emailExist(email, table):
        isEmail = False
        all_users = db.child(table).get()
        try:
            for values in all_users.each():
                if (values.val()["email"]==email):  
                    isEmail = True
            return isEmail
        except:
            print("Empty dictionary. AKA table is empty")
  
def clientExist(email):
        isEmail = False
        all_users = db.child(client_table).get()
        try:
            for values in all_users.each():
                if (values.val()["customer_email"]==email):  
                    isEmail = True
            return isEmail
        except:
            print("Empty dictionary. AKA table is empty")  
            
def approvalExist(email):
        isEmail = False
        all_users = db.child(approval_table).get()
        try:
            for values in all_users.each():
                if (values.val()["client_email"]==email):  
                    isEmail = True
            return isEmail
        except:
            print("Empty dictionary. AKA table is empty")  
            
def getKeyClient(email):
    key = ""
    all_users = db.child(client_table).get()
    try:
        for values in all_users.each():
            if (values.val()["customer_email"]==email): 
                key = values.key()
            return key
    except:
        print("Empty dictionary. AKA table is empty")
        
def addusers(email, password, table):
    newUser = {"email": email, "password": password}
    db.child(table).push(newUser)
    
def removeUser(email, table):
    key = getKey(email, table)
    db.child(table).child(key).remove()
             
            
def dropTable(table):
    all_users = db.child(table).get()
    try:
        for values in all_users.each(): 
            key = values.key()
            db.child(table).child(key).remove()
    except:
        print("Empty dictionary. AKA table is empty")

 
    
def getKey(email, table):
    key = ""
    all_users = db.child(table).get()
    try:
        for values in all_users.each():
            if (values.val()["email"]==email): 
                key = values.key()
            return key
    except:
        print("Empty dictionary. AKA table is empty")
    
    
    
    